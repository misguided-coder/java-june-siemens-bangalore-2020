class LoopsDemo {

	public static void main(String[] args) {
		//UC1();		
		//UC2();		
		//UC3();		
		//UC4();		
		//UC5();		
		UC6();		
		System.out.println("Finish Line!!");
	}	

	private static void UC6() {
		
		for(int i=1,j=1;i <= 10;i++,j++) {
			System.out.println("I : "+i+" J : "+j);
		}		
		
		System.out.println("Done processing!!!!");
	}


	private static void UC5() {
		
		int counter = 10;
		for(;counter >= 1;counter--) {
			System.out.println("Go Corona Go!! "+counter);
		}		
		
		System.out.println("Done processing!!!!");
	}

	private static void UC4() {
	
		for(int counter = 10;counter >= 1;counter--) {
			System.out.println("Go Corona Go!! "+counter);
		}		
		
		System.out.println("Done processing!!!!");
	}

	private static void UC3() {

		for(int counter = 1;counter <= 10;counter++) {
			System.out.println("Go Corona Go!!");
		}		
		
		System.out.println("Done processing!!!!");
	}
	
	private static void UC2() {

		int counter = 1;
		do {
			System.out.println("Go Corona Go!!");
			counter  +=  1;
		} while(counter <= 10);		
		
		System.out.println("Done processing!!!!");
	}	

	private static void UC1() {
		
		int counter = 1;
		while(counter <= 10) {
			System.out.println("Go Corona Go!!");
			counter  = counter + 1;
		}		
		
		System.out.println("Done processing!!!!");
	}	
}