class AirportDemo {

	public static void main(String[] args) {
		//UC1();		
		//UC2();		
		UC3();		
		//UC4();		
		System.out.println("Finish Line!!");
	}	

	private static void UC3() {
			
		Airport airport1 = new Airport("DEL","Delhi International Airport","Delhi",34000,15,true);	
		Airport airport2 = new Airport("BOM","Chattarpati Shivaji International Airport","Mumbai",20000,10);	

		airport1.info();
		airport1.showAirlines();
		airport1.increaseCapacity(5000);

		airport2.info();
		airport2.showAirlines();
		airport2.increaseCapacity(5000);
	}	



	private static void UC2() {
			
		Airport airport1 = new Airport();	
		Airport airport2 = new Airport();	

		airport1.code = "DEL";
		airport1.name = "Indira Gandhi Internaltional Airport";
		airport1.city = "New Delhi";
		airport1.passengerCapacity = 35000;
		airport1.airlines = 12;
		airport1.international = true;
		
		airport2.code = "DEL";
		airport2.name = "Indira Gandhi Internaltional Airport";
		airport2.city = "New Delhi";
		airport2.passengerCapacity = 35000;
		airport2.airlines = 12;
		airport2.international = true;

		airport1.info();
		airport1.showAirlines();
		airport1.increaseCapacity(5000);

		airport2.info();
		airport2.showAirlines();
		airport2.increaseCapacity(5000);
	}	

	private static void UC1() {
			
		//declare a refernce variable
		Airport airport = null;
		
 		//create a new instance of the class
		airport = new Airport();	

		airport.code = "DEL";
		airport.name = "Indira Gandhi Internaltional Airport";
		airport.city = "New Delhi";
		airport.passengerCapacity = 35000;
		airport.airlines = 12;
		airport.international = true;
		
		System.out.println(airport);
		System.out.println(airport.code);
		System.out.println(airport.name);
		System.out.println(airport.city);
	}	
}