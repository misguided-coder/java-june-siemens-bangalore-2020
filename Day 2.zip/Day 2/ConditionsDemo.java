class ConditionsDemo {

	public static void main(String[] args) {
		//UC1();		
		//UC2();		
		//UC3();		
		//UC4();		
		//UC5();		
		UC6();		
		System.out.println("Finish Line!!");
	}	


	private static void UC6() {
	
		int amount = 20000;
		String result =  amount > 50000 ? "Rich Guy" : "Poor Guy";
		System.out.println(result);
	}

	private static void UC5() {
	
		int amount = 90000;
		
		switch(amount) {
   			case 50000 :
				System.out.println("You are little rich!!");
				break;
 			case 80000 :
				System.out.println("You are rich!!");
				break;
 			case 90000 :
				System.out.println("You are very rich!!");
				break;
 			default :
				System.out.println("You wealth is nor known!!");
		}

		System.out.println("Done with processing!!");
	}

	private static void UC4() {
	
		int age = 5;
		double  balance = 400000.00;
		
		if(age <= 10) { 
		  System.out.println("You are just a kid!!");
		  if(balance > 500000.00) {
			System.out.println("You are rich also!!");
		  } else {
			System.out.println("You are poor guy!!");
		  }
		} else {
			System.out.println("You have grown!!");
			if(balance > 500000.00) {
				System.out.println("You are rich also!!");
		  	} else {
				System.out.println("You are poor guy!!");
		  	}
		}
	}

	private static void UC3() {
	
		int age = 5;
		double  balance = 800000.00;
		
		if(age <= 10 && balance > 500000.00) {
			System.out.println("You are just a kid but rich!!");
		} else {
			System.out.println("You have grown!!");
		}
	}
	
	private static void UC2() {

		int age = 25;
		if(age <= 10) {
			System.out.println("You are just a kid!!");
		} else {
			System.out.println("You have grown!!");
		}
	}	

	private static void UC1() {
		
		int age = 5;
		if(age <= 10) {
			System.out.println("You are just a kid!!");
		}
	}	
}