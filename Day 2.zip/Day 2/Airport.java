class Airport {

	String code;
	String name;
	String city;
	int passengerCapacity;
	int airlines;
	boolean international;

	Airport() {

	}

	Airport(String code,String name,String city,int passengerCapacity,int airlines) {
		this.code = code;	
		this.name = name;	
		this.city = city;	
		this.passengerCapacity = passengerCapacity;	
		this.airlines = airlines;	
		this.international = false;	
	}

	Airport(String code,String name,String city,int passengerCapacity,int airlines,boolean international) {
		this.code = code;	
		this.name = name;	
		this.city = city;	
		this.passengerCapacity = passengerCapacity;	
		this.airlines = airlines;	
		this.international = international;	
	}



	void info() {
		System.out.printf("Code : %s%n",this.code);
		System.out.printf("Name : %s%n",this.name);
		System.out.printf("City : %s%n",this.city);
		System.out.printf("Capacity : %s%n",this.passengerCapacity);
		System.out.printf("Airlines : %s%n",this.airlines);
		System.out.printf("International : %s%n",this.international);
	}

	void showAirlines() {
		System.out.println("Airlines Served : "+this.airlines);
	}

	void increaseCapacity(int capacity) {
		this.passengerCapacity = this.passengerCapacity + capacity; 		
		System.out.println("Airport passenger capacity modified to "+this.passengerCapacity);
	}
	
}