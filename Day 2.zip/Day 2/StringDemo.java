class StringDemo {

	public static void main(String[] args) {
		//UC1();		
		//UC2();		
		//UC3();		
		UC4();		
		System.out.println("Finish Line!!");
	}	

	private static void UC4() {
		
		String name = "Ritesh"; //literal way
		System.out.println("Length : "+name.length());
		System.out.println(name);
	}	

	private static void UC3() {
		
		String name = new String("Ritesh"); //instance/object way
		System.out.println("Length : "+name.length());
		System.out.println(name);
	}	


	private static void UC2() {
		
		//can hold many characters together
 		//convenient wrapper class provided by Java to hold an array of type char
                //immutable i.e. can not change its data once created
		char[] name = {'R','i','t','e','s','h'};
		String nameStr = new String(name);
		System.out.println("Length : "+name.length);
		System.out.println("Length : "+nameStr.length());
		System.out.println(name);
		System.out.println(nameStr);
	}	

	private static void UC1() {
		
		char[] name = new char[] {'R','i','t','e','s','h'};
		System.out.println("Length : "+name.length);
		System.out.println(name);
	}	
}