class TypeCastDemo {

	public static void main(String[] args) {
		//UC1();		
		//UC2();		
		//UC3();		
		UC4();		
		System.out.println("Finish Line!!");
	}	

	private static void UC4() {

		char ch = 'R';
		int i = ch;
	
		System.out.println("Char : "+ch);
		System.out.println("I : "+i);
	}	


	private static void UC3() {

		int i = 65;
		char ch = (char) i;

		System.out.println("I : "+i);
		System.out.println("Char : "+ch);
	}	


	private static void UC2() {

		//8 bytes 
		long i = 1000L; 
		
 		//4 bytes 
		int j = (int) i; //explicit casting

		System.out.println("I : "+i);
		System.out.println("J : "+j);
	}	

	private static void UC1() {
		
 		//4 bytes 
		int i = 100;

		//8 bytes 
		long j = i; //implicit casting
		
		System.out.println("I : "+i);
		System.out.println("J : "+j);
	}	
}