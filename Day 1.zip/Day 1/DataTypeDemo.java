class DataTypeDemo {

	public static void main(String[] args) {

		//Numeric Valiables
		
		//Size - 1 byte
		byte age = 26;
		System.out.println(age);	

		//Size - 2 bytes
		short chapters = 75;
		System.out.println(chapters);	

		//Size - 4 bytes
		int pages = 1200;
		System.out.println(pages);	

		//Size - 8 bytes
		long books = 450000L;
		System.out.println(books);


		//Decimal Valiables
		
		//Size - 4 bytes
		float marks = 94.40F;
		System.out.println(marks);	
	
		//Size - 8 bytes
		double balance = 900000.50;
		System.out.println(balance);	

		//Character Valiables
		
		//Size - 2 bytes
		char letter = 'R';
		System.out.println(letter);	
	
		//Boolean Valiables
		
		//Size - 1 bit
		boolean success = true;
		System.out.println(success);	

	}	
}