class ArrayDemo {

	public static void main(String[] args) {
		//UC1();		
		//UC2();		
		UC3();		
	}	

	private static void UC3() {
		
		//array declaration & initialization & population
		//int[] marks = new int[] {10,20,30,40,50,60,70,80,90,100,110,120};  
		int[] marks = {10,20,30,40,50,60,70,80,90,100,110,120};  

		System.out.println(marks);	

		System.out.println(marks.length);	

		System.out.println(marks[0]);	
		System.out.println(marks[1]);	
		System.out.println(marks[2]);	
		System.out.println(marks[3]);	
		System.out.println(marks[4]);
		System.out.println(marks[8]);
	}	



	private static void UC2() {
		
		//array declaration & initialization
		int[] marks = new int[5];  

		//array population
		marks[0] = 100;
		marks[1] = 200;
		marks[2] = 300;
		marks[3] = 400;
		marks[4] = 500;

		System.out.println(marks);	
		System.out.println(marks.length);	


		System.out.println(marks[0]);	
		System.out.println(marks[1]);	
		System.out.println(marks[2]);	
		System.out.println(marks[3]);	
		System.out.println(marks[4]);
	}	


	private static void UC1() {
		
		//array declaration
		int[] marks;

		//array initialization
		marks = new int[5];  //lower bound is 0 //upper bound is 4

		//array population
		marks[0] = 100;
		//marks[1] = 200;
		//marks[2] = 300;
		marks[3] = 400;
		marks[4] = 500;

		System.out.println(marks);	

		System.out.println(marks[0]);	
		System.out.println(marks[1]);	
		System.out.println(marks[2]);	
		System.out.println(marks[3]);	
		System.out.println(marks[4]);
	}	
}